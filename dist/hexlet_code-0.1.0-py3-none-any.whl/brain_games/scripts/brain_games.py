#!/usr/bin/env python3
def games(tex):
    print(tex)

def main():
    games('Welcome to the Brain Games!')

if __name__ == '__main__':
    main()
